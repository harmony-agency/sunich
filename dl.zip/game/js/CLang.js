var TEXT_GAMEOVER   = "سه تا جونت تموم شد";
var TEXT_SCORE      = "امتیاز شما";
var TEXT_BEST_SCORE = " بهترین امتیاز شما";
var TEXT_ARE_YOU_SURE = "مطمئنی؟";
var TEXT_DEVELOPED  = "طراحی و پیاده سازی شده";
var TEXT_ERR_LS = "YOUR WEB BROWSER DOES NOT SUPPORT LOCAL STORAGE. IF YOU'RE USING SAFARI, IT MAY BE RELATED TO PRIVATE BROWSING. AS A RESULT, SOME INFO MAY NOT BE SAVED OR SOME FEATURES MAY NOT BE AVAILABLE.";
var TEXT_PRELOADER_CONTINUE = "شروع";
var TEXT_READY = "آماده!";
var TEXT_GO = "برو";
var TEXT_COLLECT = "جمع آوری کنید";
var TEXT_AVOID = "اجتناب کردن";
var TEXT_MOVE = "حرکت";
var TEXT_HELP_DESKTOP = "از کلیدهای جهت دار برای حرکت دادن قهرمان خود استفاده کنید!";
var TEXT_HELP_MOBILE = "برای حرکت دادن قهرمان خود، انگشت خود را بکشید!";


var TEXT_SHARE_IMAGE = "200x200.jpg";
var TEXT_SHARE_TITLE = "تبریک می گویم!";
var TEXT_SHARE_MSG1 = "امتیاز جمع آوری شده : <strong>";
var TEXT_SHARE_MSG2 = "امتیاز</strong>!<br><br>امتیاز خود را با دوستان خود به اشتراک بگذارید!";
var TEXT_SHARE_SHARE1 = "امتیاز شما : ";
var TEXT_SHARE_SHARE2 = " نکته ها! میتونی بهتر انجام بدی";