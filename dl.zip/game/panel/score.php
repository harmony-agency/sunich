<?php
include "config.php";
$data = [];

$score = $_POST["score"];

if(isset($score))  { 

        if($score!='' )
        {

               
     
                try {

                            $data['success'] = true;
                            $sql = "UPDATE `kids` SET `score` = $score  WHERE `id` = 1;";
                            // use exec() because no results are returned
                            $pdo->exec($sql);
                            $data['message'] = "امتیاز با موفقیت ثبت شد";
                       
                       
                    } 
             catch(PDOException $e) {
                            $data['message'] =  $sql . "<br>" . $e->getMessage();
            }
        }
        
}

echo json_encode($data);
exit();
